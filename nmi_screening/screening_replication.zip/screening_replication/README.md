# Replication code: screening machine-written scholarly text (transparent count screen vs published detectors vs LLM judges)

Code and derived data for an independent re-implementation of the screening study. **The original study's code and data were not
available; every number here comes from this re-implementation and differs from the earlier version of the work.**

## Pipeline (run in order; each script is resumable and writes to `data/`)
| step | script | what it does |
|---|---|---|
| 1 | `s1_collect_human.py` | samples 500 human papers (PubMed Central open access, arXiv; 2015-2019) |
| 2 | `s2_generate.py` | generates machine papers with three LLMs through OpenRouter (GPT-4o, Claude, Llama 3.3 70B) |
| 3 | `s3_features.py` | counts of seven linguistic events, dispersion and scale-dependent Fano/Cox features |
| 4 | `s4_screens.py` | count-based screen: within-generator, cross-generator, human-only anomaly detection |
| 5-6 | `s5_judges.py`, `s6_judge_baseline_analysis.py` | zero-shot LLM judges (GPT-4o, Gemini 2.5 Pro); judge and zero-shot detector AUCs |
| 7-8 | `s7_attacks.py`, `s8_attack_eval.py` | feature-aware edit, LLM rewrite, hybrid; scoring by every detector |
| 9 | `s9_adaptive.py` | attacks aimed at probability detectors: sentence mixing, typo noise, recursive rewrite |
| 10 | `s10_artifact_control.py` | TF-IDF baseline with header/figure/citation tokens removed and function-words-only |
| GPU | `gpu_baselines.py`, `supervised_baselines.py`, `score_attacked_supervised.py`, `gpu/`, `RUNPOD.md` | Fast-DetectGPT, Binoculars, log-likelihood/rank/entropy, TF-IDF, fine-tuned RoBERTa |

## Set-up
`pip install -r requirements.txt`. LLM calls need `OPENROUTER_API_KEY` in the environment (never stored in this repository).
`common.py` keeps a spend ledger (`data/spend.json`) and refuses calls above a cap.

## Data in `data_snapshot/`
Included: the machine-generated corpora (gz), count features, judge scores, detector scores, and every result table (AUC by detector,
generator and attack). **Not included:** the text of the human papers and the attack files that contain human sentences. Re-collect them with
`s1_collect_human.py` using `human_paper_ids.json` (identifiers, source, year, title); the generation prompts are in `s2_generate.py`.
Scores for attacked documents (`attacked*_binoculars.csv`, `*_results.csv`) are included.

## Known limits
Three generators, one genre, English; a judged sample of 500 excerpts; the Gemini judge run on mix50 attacks stopped at a spend cap
(264 of 300 excerpts). Fine-tuned RoBERTa and TF-IDF are strong within a generator but their cross-generator AUC drops once
structural artifacts are removed (`s10_artifact_control.py`). Log-likelihood and entropy AUCs below 0.5 under sentence mixing/typo noise are
real: such text is less probable than genuine human text.

## License
MIT (code). Machine-generated texts are provided for research use. Author: Ook Lee.
