# Replication code: screening machine-written scholarly text (transparent count screen vs published detectors vs LLM judges)

Code and derived data for an independent re-implementation of the screening study. **The original study's code and data were not
available; every number here comes from this re-implementation and differs from the earlier version of the work.**

## Pipeline (run in order; each script is resumable and writes to `data/`)
| step | script | what it does |
|---|---|---|
| 1 | `s1_collect_human.py` | samples 500 human papers (PubMed Central open access, arXiv; 2015-2019) |
| 2 | `s2_generate.py` | generates machine papers with three LLMs through OpenRouter (GPT-4o, Claude, Llama 3.3 70B) |
| 3 | `s3_features.py` | counts of seven linguistic events, dispersion and scale-dependent Fano/Cox features |
| 4 | `s4_screens.py` | count-based screen: within-generator, cross-generator, human-only anomaly detection |
| 5-6 | `s5_judges.py`, `s6_judge_baseline_analysis.py` | zero-shot LLM judges (GPT-4o, Gemini 2.5 Pro); judge and zero-shot detector AUCs |
| 7-8 | `s7_attacks.py`, `s8_attack_eval.py` | feature-aware edit, LLM rewrite, hybrid; scoring by every detector |
| 9 | `s9_adaptive.py` | attacks aimed at probability detectors: sentence mixing, typo noise, recursive rewrite |
| 10 | `s10_artifact_control.py` | TF-IDF baseline with header/figure/citation tokens removed and function-words-only |
| GPU | `gpu_baselines.py`, `supervised_baselines.py`, `score_attacked_supervised.py`, `gpu/`, `RUNPOD.md` | Fast-DetectGPT, Binoculars, log-likelihood/rank/entropy, TF-IDF, fine-tuned RoBERTa |

## Set-up
`pip install -r requirements.txt`. LLM calls need `OPENROUTER_API_KEY` in the environment (never stored in this repository).
`common.py` keeps a spend ledger (`data/spend.json`) and refuses calls above a cap.

## Data in `data_snapshot/`
Included: the machine-generated corpora (gz), count features, judge scores, detector scores, and every result table (AUC by detector,
generator and attack). **Not included:** the text of the human papers and the attack files that contain human sentences. Re-collect them with
`s1_collect_human.py` using `human_paper_ids.json` (identifiers, source, year, title); the generation prompts are in `s2_generate.py`.
Scores for attacked documents (`attacked*_binoculars.csv`, `*_results.csv`) are included.

## Known limits
Three generators, one genre, English; a judged sample of 500 excerpts; the Gemini judge run on mix50 attacks stopped at a spend cap
(264 of 300 excerpts). Fine-tuned RoBERTa and TF-IDF are strong within a generator but their cross-generator AUC drops once
structural artifacts are removed (`s10_artifact_control.py`). Log-likelihood and entropy AUCs below 0.5 under sentence mixing/typo noise are
real: such text is less probable than genuine human text.

## License
MIT (code). Machine-generated texts are provided for research use. Author: Ook Lee.

## Version 2: guided attacks, a fourth generator, a third field and the defence study
| step | script | what it does |
|---|---|---|
| 11 | `s11_collect_econ.py` | 130 economics papers (arXiv econ.*, 2017-2019); `s2_generate.py --human human_econ.jsonl --tag econ_` writes machine papers on the same topics |
| 2 | `s2_generate.py --gen deepseek` | DeepSeek V4.1 Flash as a fourth generator (low reasoning effort) |
| 12 | `s12_bestofk.py` | detector-guided candidates: four LLM rewrites and four 50% sentence mixes per paper |
| 13 | `s13_ext_build.py ds_attacks / econ_attacks` | the six attacks on DeepSeek papers; mixing and typos on economics papers |
| 14 | `s14_prepare.py calib / select / sup`, `s14_screen.py`, `ext_train_score.py`, `s14_assemble.py` | 100 calibration humans; keep the candidate with the lowest Fast-DetectGPT score; per-target train/test files; count screen, TF-IDF and RoBERTa per-document scores; assemble all scores |
| 15 | `s15_defence.py` | two-sided score, ensembles, AUC with bootstrap intervals, operating points (`defence_results.csv`) |
| GPU | `gpu/create_pod.py`, `gpu/runA1.sh`, `gpu/runA_fix.sh`, `gpu/runA2.sh`, `gpu/runB.sh` | zero-shot scores of candidates and new documents; RoBERTa per target |

New derived data in `data_snapshot/`: `defence_scores.csv` (per-document scores of every detector), `defence_results.csv`,
`pod_A1_scores.csv`, `pod_A2_scores.csv`, `sup/` (RoBERTa, TF-IDF and count-screen scores per target), judge scores of the new
attacks, `cal_ids.json`, the DeepSeek and economics machine papers, and the guided-rewrite candidates (`bestofk_rw_cands.jsonl.gz`).
Not included, because they contain text from human papers: human papers (re-collect with `human_paper_ids.json`,
`human_econ_paper_ids.json`), mixed-sentence attacks and guided-mixing candidates (rebuild with the scripts and the fixed seeds).
