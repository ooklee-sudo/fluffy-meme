# Code package: When Can Platforms Trust Synthetic Agents?

Contents
- pilot/            simulation runners (run_full.py, run_h6.py, run_c1.py, run_h6c.py, run_c2.py, run_gen.py), analysis scripts (analyze_*.py), factual battery (h6_battery.py)
- benchmarks/       compute_human_benchmarks.py: human effects from the public Twin-2K-500 data and mega-study
- prereg/           pre-registration texts (#320110, #320124), amendment, working document
- results/          summary tables of every study (c1, c2, e1, e2, h6c, s)
- figures/          make_forest.py and Figure 1 (forest plot of C1 effects)
- paper_src/        manuscript source (content.js, make.js) and submission/build/ builders for appendix, title page, cover letter

Mapping of study names: E1 = full-run simulations (pilot/run_full.py), E2 = reasoning pilot (run_h6.py), C1 = run_c1.py, H6c = run_h6c.py, C2 = run_c2.py, S = run_gen.py.

Setup
  python3 -m pip install -r requirements.txt
  An API key for an LLM aggregator is needed for the runners (they call https://openrouter.ai/api/v1/chat/completions; set credentials in your environment or proxy).
  Download the public data (not redistributed here): huggingface.co/datasets/LLM-Digital-Twin/Twin-2K-500 (question_catalog_and_human_response_csv/wave1_3_response_label.csv, wave4_response_label.csv, full_persona/chunks/*.parquet),
  huggingface.co/datasets/LLM-Digital-Twin/Twin-2K-500-Mega-Study (data/default_eric, context_effects, targeting_fairness parquet), and the Upworthy Research Archive (OSF jd64p; exploratory and confirmatory package CSVs).
  persona_summary.parquet is built from the persona chunks (columns pid, persona_summary; PID = "pid_" + pid).

Run order (examples; <data> is the data directory, <out> an output directory)
  python3 benchmarks/compute_human_benchmarks.py <data> <data> [<twin_csv_dir>]
  python3 pilot/run_c1.py <data> <out>/c1 600 120      then  python3 pilot/analyze_c1.py <out>/c1/raw.jsonl <out>/c1/final 1000
  python3 pilot/run_h6c.py <data> <out>/h6c 100 60     then  python3 pilot/analyze_h6c.py <out>/h6c/raw.jsonl <out>/h6c/final
  python3 pilot/run_c2.py <data> <upworthy confirmatory csv> <out>/c2conf 1000 2026 5 100 persona,nopersona
  python3 pilot/analyze_c2.py <out>/c2conf <out>/c2conf/final2 500   and   python3 pilot/analyze_c2_verdict.py <out>/c2conf <out>/c2conf/final 1000
  python3 pilot/run_gen.py <data> <out>/gen 200 130    then  python3 pilot/analyze_gen.py <out>/gen/raw.jsonl <out>/gen/res 400
Seeds: 2026 (respondent draws, test draw, bootstrap), 11 (C2 development), 2027 (Study S).
Rebuild the manuscript: cd paper_src && node make.js ../manuscript.docx (needs Node.js and the docx package). Rebuild the appendix: python3 submission/build/build_appendix.py <data> out.docx.

Notes
- Raw outputs are in the separate archive 06_Raw_Model_Outputs.zip (one gzip JSON-lines file per study). Each line holds respondent id, model, settings, response text, cost, and the questions shown.
- Confirmatory analysis scripts were committed before outputs were analyzed; see the git history of the project repository.
- Known issues: fairness condition tag inverted in the public mega-study file (we code from displayed text); an indexing error in the BH routine was corrected (no verdict changed).
- License: [to be chosen by the authors].
