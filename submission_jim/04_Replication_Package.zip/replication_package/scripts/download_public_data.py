"""Download the public data used by the analyses. Usage: python3 download_public_data.py <data_dir> [--skip-persona] [--skip-upworthy]
Writes: {default_eric,context_effects,targeting_fairness}-00000-of-00001.parquet, wave1_3_response_label.csv, wave4_response_label.csv,
question_catalog.json, persona_summary.parquet (columns PID, persona_summary), upworthy/exploratory.csv, upworthy/confirmatory.csv."""
import sys, os, requests, glob
D = sys.argv[1]; os.makedirs(D, exist_ok=True)
HF = 'https://huggingface.co/datasets/LLM-Digital-Twin'
def get(url, path):
    if os.path.exists(path) and os.path.getsize(path) > 0: print('have', path); return
    with requests.get(url, stream=True, timeout=600, allow_redirects=True) as r:
        r.raise_for_status()
        with open(path, 'wb') as f:
            for chunk in r.iter_content(1 << 20): f.write(chunk)
    print('saved', path, os.path.getsize(path))
for st in ['default_eric', 'context_effects', 'targeting_fairness']:
    get(f'{HF}/Twin-2K-500-Mega-Study/resolve/main/data/{st}-00000-of-00001.parquet', f'{D}/{st}-00000-of-00001.parquet')
base = f'{HF}/Twin-2K-500/resolve/main/question_catalog_and_human_response_csv'
get(f'{base}/wave1_3_response_label.csv', f'{D}/wave1_3_response_label.csv'); get(f'{base}/wave4_response_label.csv', f'{D}/wave4_response_label.csv')
get(f'{base}/question_catalog.json', f'{D}/question_catalog.json')
if '--skip-persona' not in sys.argv:
    import pandas as pd
    parts = []
    for i in range(1, 8):
        p = f'{D}/persona_chunk_{i:03d}.parquet'; get(f'{HF}/Twin-2K-500/resolve/main/full_persona/chunks/persona_chunk_{i:03d}.parquet', p)
        parts.append(pd.read_parquet(p, columns=['pid', 'persona_summary']))
    df = pd.concat(parts); df['PID'] = 'pid_' + df['pid'].astype(str); df[['PID', 'persona_summary']].to_parquet(f'{D}/persona_summary.parquet')
    for p in glob.glob(f'{D}/persona_chunk_*.parquet'): os.remove(p)
if '--skip-upworthy' not in sys.argv:
    os.makedirs(f'{D}/upworthy', exist_ok=True)
    root = requests.get('https://api.osf.io/v2/nodes/jd64p/files/osfstorage/', timeout=60).json()['data']
    folder = [x for x in root if x['attributes']['name'] == 'upworthy-archive-datasets'][0]['id']
    files = requests.get(f'https://api.osf.io/v2/nodes/jd64p/files/osfstorage/{folder}/', timeout=60).json()['data']
    for x in files:
        n = x['attributes']['name']
        for key, out in [('exploratory-packages', 'exploratory.csv'), ('confirmatory-packages', 'confirmatory.csv')]:
            if key in n: get(f"https://files.osf.io/v1/resources/jd64p/providers/osfstorage/{x['id']}?action=download", f'{D}/upworthy/{out}')
print('done')
