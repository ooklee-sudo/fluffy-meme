#!/bin/bash
# Re-run every analysis from the shipped raw outputs. Usage: bash reproduce_analyses.sh <data_dir> <work_dir>
set -e
DATA="$(cd "$1" && pwd)"; WORK="$2"; HERE="$(cd "$(dirname "$0")/.." && pwd)"; mkdir -p "$WORK"; WORK="$(cd "$WORK" && pwd)"
for pair in E1_full_runs:e1 E2_reasoning_pilot:e2 C1_confirmatory_twin:c1 H6c_reasoning_grid:h6c C2_field_confirmatory:c2conf S_stability:s; do
  f="${pair%%:*}"; d="${pair##*:}"; mkdir -p "$WORK/$d"; gunzip -c "$HERE/raw_outputs/$f.jsonl.gz" > "$WORK/$d/raw.jsonl"
  [ -f "$HERE/raw_outputs/${f}_tests.json" ] && cp "$HERE/raw_outputs/${f}_tests.json" "$WORK/$d/tests.json" || true
done
cd "$HERE/code"
echo "== human benchmarks"; python3 -I ../benchmarks/compute_human_benchmarks.py "$DATA" "$DATA" > "$WORK/benchmarks.txt"
echo "== E1";  python3 -I analyze_twins.py "$DATA" "$WORK/e1/raw.jsonl" "$WORK/e1/res_final.csv" > "$WORK/e1/analysis.txt"
echo "== E2";  python3 -I analyze_h6.py "$DATA" "$WORK/e2/raw.jsonl" "$WORK/e2/final" > "$WORK/e2/analysis_final.txt"
echo "== C1";  python3 -I analyze_c1.py "$WORK/c1/raw.jsonl" "$WORK/c1/final" 1000 > "$WORK/c1/analysis.txt"
echo "== H6c"; python3 -I analyze_h6c.py "$WORK/h6c/raw.jsonl" "$WORK/h6c/final" > "$WORK/h6c/analysis.txt"
echo "== C2";  python3 -I analyze_c2.py "$WORK/c2conf" "$WORK/c2conf/final2" 500 > /dev/null; python3 -I analyze_c2_verdict.py "$WORK/c2conf" "$WORK/c2conf/final" 1000 > "$WORK/c2conf/verdict.txt"
echo "== S";   python3 -I analyze_gen.py "$WORK/s/raw.jsonl" "$WORK/s/res" 400 > "$WORK/s/analysis.txt"
echo "all analyses finished; now run: python3 scripts/compare_results.py $WORK results/"
