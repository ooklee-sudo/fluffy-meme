"""Compare regenerated summary tables with the shipped ones. Usage: python3 compare_results.py <work_dir> <results_dir>"""
import sys, os, pandas as pd, numpy as np
W, R = sys.argv[1], sys.argv[2]
pairs = [('c1/final_effects.csv', 'c1/final_effects.csv'), ('c1/final_propositions.csv', 'c1/final_propositions.csv'), ('h6c/final_cells.csv', 'h6c/final_cells.csv'), ('h6c/final_propositions.csv', 'h6c/final_propositions.csv'),
         ('c2conf/final_verdicts.csv', 'c2/final_verdicts.csv'), ('c2conf/final2_summary.csv', 'c2/final2_summary.csv'), ('s/res_cells.csv', 's/res_cells.csv'), ('e1/res_final.csv', 'e1/res_final.csv'), ('e2/final_cells.csv', 'e2/final_cells.csv')]
ok = True
for a, b in pairs:
    pa, pb = os.path.join(W, a), os.path.join(R, b)
    if not (os.path.exists(pa) and os.path.exists(pb)): print('MISSING', a, b); ok = False; continue
    x, y = pd.read_csv(pa), pd.read_csv(pb)
    if x.shape != y.shape: print('SHAPE DIFF', a, x.shape, y.shape); ok = False; continue
    num = [c for c in x.columns if pd.api.types.is_numeric_dtype(x[c]) and not pd.api.types.is_bool_dtype(x[c]) and c in y.columns]; txt = [c for c in x.columns if c not in num and c in y.columns]
    d = max([float(np.nanmax(np.abs(x[c].values - y[c].values))) if len(x) else 0.0 for c in num] + [0.0]); same = all((x[c].fillna('') == y[c].fillna('')).all() for c in txt)
    flag = 'OK ' if d < 1e-6 and same else 'DIFF'; ok &= flag == 'OK '; print(flag, a, 'max abs diff', f'{d:.2e}', 'text identical' if same else 'TEXT DIFFERS')
print('ALL MATCH' if ok else 'SOME DIFFERENCES')
