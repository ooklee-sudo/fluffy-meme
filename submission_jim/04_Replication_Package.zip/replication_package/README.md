# Replication package
**When Can Marketers Trust Synthetic Consumers? Validity Regions and a Validation Protocol for LLM Digital Twins in Digital Experimentation**

This package contains everything needed to (A) reproduce every table, figure, and verdict in the manuscript and Web Appendix from the model outputs
without calling any model, and (B) re-run the simulations (costs money; needs an API key). Human data are public and are downloaded by a script
(they are not redistributed here).

## Contents
| Folder | What it holds |
|---|---|
| `code/` | simulation runners (`run_*.py`), analysis scripts (`analyze_*.py`), factual battery (`h6_battery.py`) |
| `benchmarks/` | `compute_human_benchmarks.py`: human effects from the public data |
| `scripts/` | `download_public_data.py`, `reproduce_analyses.sh`, `compare_results.py` |
| `raw_outputs/` | every model response used in the paper, one gzip JSON-lines file per study, plus `*_tests.json` for the field tests |
| `results/` | the summary tables produced for the paper (what the scripts regenerate) |
| `figures/` | `make_forest.py` and Figure 1 (PNG, PDF) |
| `prereg/` | AsPredicted #320110 and #320124 texts, amendment note, working document |
| `paper_src/` | manuscript source (`content_ama.json`, `make_ama.js`) |

## Study names
E1 = exploratory twin simulations (`run_full.py`), E2 = exploratory reasoning pilot (`run_h6.py`), C1 = confirmatory twin study (`run_c1.py`),
H6c = confirmatory reasoning grid (`run_h6c.py`), C2 = confirmatory field test (`run_c2.py`), S = stability study (`run_gen.py`).
C1, H6c, and C2 were run under AsPredicted #320110 and #320124. Analysis code for these studies was committed before their outputs were analyzed.

## Requirements
Python 3.10+ with `pip install -r requirements.txt`. Node.js and the `docx` npm package are needed only to rebuild the manuscript. `soffice` (LibreOffice) is needed only for PDFs.

## A. Reproduce the analyses from the shipped outputs (no API key, a few minutes)
1. Download the public human data (about 300 MB): `python3 scripts/download_public_data.py data/`
2. Re-run all analyses: `bash scripts/reproduce_analyses.sh data/ work/`
3. Compare with the shipped results: `python3 scripts/compare_results.py work/ results/`
   Bootstrap seeds are fixed, so the regenerated tables should match the shipped ones up to floating-point noise.
4. Rebuild Figure 1: `python3 figures/make_forest.py results/c1/final_effects.csv figures/Figure1_forest_C1`

## B. Re-run the simulations (optional; costs about US$306 in API calls at October 2026 prices)
Set `OPENROUTER_API_KEY` (an OpenRouter key) and run, for example:
```
python3 code/run_c1.py data/ out/c1 600 120
python3 code/run_h6c.py data/ out/h6c 100 60
python3 code/run_c2.py data/ data/upworthy/confirmatory.csv out/c2conf 1000 2026 5 100 persona,nopersona
python3 code/run_gen.py data/ out/gen 200 130
python3 code/run_full.py data/ out/full2 300
python3 code/run_h6.py data/ out/h6 100 100 80
```
The last two numbers of each command are respondent counts and a hard USD stop. Model identifiers are the aggregator names listed in Web Appendix Table W5;
models are updated or retired over time, so re-runs will not reproduce the outputs exactly. The reproducible object is the analysis of the shipped outputs.

## Known issues
- The raw condition tag (`EmbeddedData.target`) in the targeting-fairness mega-study file is inverted relative to the shown text; all analyses code conditions from the text.
- The run scripts did not send an API key header in the original runs (credentials were injected by a proxy); the `HDR` line that reads `OPENROUTER_API_KEY` was added afterwards. No other change was made to the run scripts after the studies.
- An indexing error in the Benjamini-Hochberg routine was corrected after the C2 evaluation; shipped results are from the corrected code.
- The provider that served each call was chosen by the aggregator and was not recorded.

## Data sources and licenses
Twin-2K-500 (CC BY 4.0) and its mega-study (Apache-2.0): huggingface.co/datasets/LLM-Digital-Twin. Upworthy Research Archive: OSF project jd64p.
Code license: [to be chosen by the authors before release].
