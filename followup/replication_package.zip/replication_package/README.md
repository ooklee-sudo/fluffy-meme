# Replication package: update procedures for language models after statutory amendments

Code, data and result files for the manuscript prepared for *Artificial Intelligence and Law*. Version of 3 Nov 2026.
Everything below is run from the root of this folder. No API key is needed; models are downloaded from the Hugging Face Hub (Qwen2.5-1.5B/3B/7B, Pythia-70M).

## Contents
| Path | What |
|---|---|
| `lm_supersession_gpu.py`, `lm_supersession.py` | Synthetic bank 1 (independent facts): retention strength vs share of superseded facts (LoRA, GPU / 70M full fine-tune, CPU). Also provides the shared training and scoring functions. |
| `lm_autoscope_gpu.py` | Stream-scoped retention, matching accuracy, replay baseline (Section 6.2). |
| `lm_regulatory_gpu.py` | Fictional statutes with three paraphrases (Section 6.7). |
| `lm_ripple_gpu.py` | Base and dependent provisions, listing, rule statements (Section 6.3). |
| `lm_reallaw_gpu.py` | Real amendments: fine-tuning procedures, controls, hard-alternative and log-margin metrics (Sections 6.4, Tables 6–7). |
| `lm_editors_gpu.py` | MEMIT and ROME through EasyEdit, in-context editing (Table 8). |
| `lm_rag_gpu.py` | In-context editing diagnosis and TF-IDF retrieval baseline (Section 6.6, Table 9). |
| `real_law/` | Real-amendment data and the scripts that built it (see `real_law/README.md`). `real_fact_bank_v2.json` is the bank used in the paper (27 amended provisions + 66 curated controls); `real_fact_bank.json` is the earlier 117-fact bank (90 controls). |
| `results/` | Result JSON files and run logs for every experiment reported. |
| `resA/B/C.json` | 70M-parameter runs of the first experiment. |
| `paper/` | `make_figures.py`, `build_manuscript.py` (builds all tables from the result files) and the figures. |
| `analyze_*.py` | Early analysis scripts; they read earlier result files and are not needed for the paper. |

## Result files used by the paper
`resA/B/C.json` (Table 3, Fig. 1), `results/qwen15_full.json`, `results/autoscope_qwen7b.json` (Table 4, Fig. 2), `results/ripple_qwen7b*.json`, `results/ripple_rule_qwen7b*.json` (Table 5), `results/regulatory_qwen7b.json` (6.7),
`results/reallaw_v2.json` (Tables 6–7, Fig. 3; seeds 1–2 from the first run, seed 3 from `reallaw_v2_s3.json`, merged), `results/editors_v2.json` (Table 8), `results/rag_qwen7b.json` (Tables 8–9).
Files `reallaw_qwen7b.json`, `reallaw_sweep_qwen7b.json`, `editors_qwen7b_*.json` come from an earlier version of the real-data experiments (90 controls, subject = whole prompt, 3,000 covariance samples) and are kept for transparency only.

## Reproduce
```bash
pip install -r requirements.txt
python paper/make_figures.py && python paper/build_manuscript.py   # rebuilds tables and figures from results/ (CPU, seconds)
```
Rerunning the experiments (single 80 GB GPU; Qwen2.5-7B with LoRA; roughly 5–15 minutes per seed and configuration group):
```bash
# real amendments (Tables 6-7)
python lm_reallaw_gpu.py --model Qwen/Qwen2.5-7B --bank real_law/real_fact_bank_v2.json --seeds 1 2 3 --out reallaw_v2.json \
  --configs none:0:0.5:0 unscoped:1:0.5:0 unscoped:10:0.5:0 ss:10:0.5:0 dep:10:0.5:0 ss:10:1:1 \
  none:0:0.1:0 dep:10:0.1:0 ss:10:0.1:0 none:0:0.25:0 dep:10:0.25:0 ss:10:0.25:0 none:0:0.75:0 dep:10:0.75:0 ss:10:0.75:0
# in-context editing and retrieval (Table 9)
python lm_rag_gpu.py --model Qwen/Qwen2.5-7B --bank real_law/real_fact_bank_v2.json --seeds 1 2 3 --out rag_qwen7b.json
# MEMIT / ROME (Table 8): clone EasyEdit to /work/EasyEdit; the launch model is saved to /work/qwen2.5-7b-launch (the path must contain "qwen2")
python lm_editors_gpu.py --model Qwen/Qwen2.5-7B --bank real_law/real_fact_bank_v2.json --seeds 1 2 3 --editors memit rome --stats-n 10000 --out editors_v2.json
# synthetic experiments
python lm_supersession_gpu.py --model Qwen/Qwen2.5-1.5B --seeds 1 2 3 --out qwen15.json
python lm_autoscope_gpu.py --model Qwen/Qwen2.5-7B --seeds 1 2 3 --out autoscope_qwen7b.json
python lm_ripple_gpu.py --model Qwen/Qwen2.5-7B --seeds 1 2 3 --out ripple_qwen7b.json
python lm_regulatory_gpu.py --model Qwen/Qwen2.5-7B --seeds 1 2 3 --out regulatory_qwen7b.json
```
The exact arguments of the synthetic runs are in the header of each script and in the logs under `results/`; check them against the logs before relying on the commands above. The 7B runs used one NVIDIA H100/H200 80 GB GPU (see `results/gpu.txt`); runs up to 3B used a laptop GPU with 8 GB. Results can differ slightly between GPUs and library versions.

## Data and licence
Statutory text in `real_law/` was retrieved from legislation.gov.uk on 3 Nov 2026 (Crown copyright; Open Government Licence v3.0). Check the site's terms before redistributing the quoted text. The text is research data and not legal advice. `real_law/crawl.py` re-creates the raw data from the site. Control prompts were curated by hand (`real_law/curate_controls.py` lists the 24 removed items).
Add the code licence of your choice before deposit. Authors and DOI: [to be completed].
