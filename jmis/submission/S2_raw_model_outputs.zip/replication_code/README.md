# Supplementary File S2: raw model outputs

Anonymized for double-blind review. `raw/main_run_raw.jsonl.gz` holds all 176,400 calls of the main run (fourteen models, 12,600 calls each), one JSON object per line; `raw/main.jsonl.meta.json` has the run metadata. Unzip this file inside the `replication_code` directory of Supplementary File S1 so that `raw/` sits next to `bank/`; the commands in that README then work unchanged. Field names are listed in the README of S1 (Data schema).
