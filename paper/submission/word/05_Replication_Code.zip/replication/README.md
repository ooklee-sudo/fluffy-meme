# Replication Package

"Who Pays for the Next Attempt? Contract Design and Escalation Rules for AI-Assisted Software Maintenance"

This package contains the code that produces every number, table, and figure in the manuscript, the
HumanEvalFix sampling outcomes we generated, and the expected output of each script. Identifying
information has been removed for review.

## Contents

    contracts/          analytical model, equilibria, calibration, sensitivity, proof checks
    empirical/          RepairBench and SWE-bench analyses
    empirical/sampling/ HumanEvalFix sampling, analysis, and our sampled outcomes (raw_*.jsonl)
    expected_output/    output of each script as used in the manuscript and online appendix
    requirements.txt    Python packages and versions

## Environment

Python 3.13 with the packages in requirements.txt. Scripts in contracts/ import contracts.py and
each other, so run them from inside contracts/. Random seeds are fixed in each script.

## Run order and mapping to the manuscript

| Manuscript item | Script (folder) |
|---|---|
| Table 1, Figure 1 | running_example.py (contracts) |
| Table 2 | incentive_rent_table.py (contracts) |
| Table 3 and the 296-draw comparison (Section 5.1) | contracts.py, robustness.py (contracts) |
| Section 5.2 | asymmetric.py, then asym_sweep.py (contracts) |
| Table 4 and the 240-cell sweep (Section 5.3) | diff_bertrand.py, then diff_sweep.py (contracts) |
| Section 5.4 calibration, Table 5, Figure 2 | calibration.py, sensitivity.py, fig_sensitivity.py (contracts) |
| Online Appendix D numerical checks | verify_proofs.py, general_theory.py (contracts) |
| Section 6, RepairBench | load_repairbench.py, then analyze.py (empirical) |
| Section 6, SWE-bench | swebench_repo_level.py (empirical) |
| Section 6, HumanEvalFix | analyze_hef.py; sampling with sample_humanevalfix.py (empirical/sampling) |

Each script writes a results_*.txt file in its own folder; compare it with expected_output/.

## Data

- RepairBench results: clone the public RepairBench repository (we used the commit of 26 October 2025)
  and run `python3 load_repairbench.py <REPAIRBENCH_CLONE>/results`. This writes bug_counts.json,
  which analyze.py reads. The repository carries no license file, so its data are not redistributed here.
- SWE-bench submissions: clone the public SWE-bench experiments repository and run
  `python3 swebench_repo_level.py <SWE_BENCH_EXPERIMENTS_CLONE>/evaluation`.
- HumanEvalFix: our sampled outcomes are included (raw_*.jsonl: task, sample index, pass/fail,
  token counts, billed cost; no generated code), so `python3 analyze_hef.py` reproduces Section 6
  directly. To re-sample, download the Python split of the HumanEvalPack dataset (Hugging Face,
  bigcode/humanevalpack, file python/test-00000-of-00001.parquet, MIT license), save it as
  hep_python.parquet in empirical/sampling/, set OPENROUTER_API_KEY, and run
  `python3 sample_humanevalfix.py <model> 40` for meta-llama/llama-3.2-3b-instruct,
  mistralai/ministral-8b-2512 and google/gemma-3-4b-it. Model outputs vary between runs, so
  re-sampled numbers will differ slightly from ours. Our sampling cost was $0.56.
- Prices and statistics used in calibration.py are constants taken from the public sources cited in
  Section 5.4 of the manuscript (accessed 25 October 2026).
