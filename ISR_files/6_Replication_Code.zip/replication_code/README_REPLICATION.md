# Replication package

Code and derived data for the manuscript "Where to Look First: Heterogeneity, Position, and the Value of Targeted Verification of Language-Model Output". Anonymized for double-anonymous review.

## Contents
- `*.py`, `run_ext.sh`: pipeline (collect entities, generate text, label claims with a language-model judge, sentence-level analysis, allocation policies, human-verifier model, public-human-label evaluation).
- `data/`: generated texts (`gen_*.jsonl`), judge labels (`lab*_*.jsonl`) and counterfactual runs (`cf_*.jsonl`). Source annotations (FActScore, WikiBio-GPT3, RAGTruth) and Wikipedia text are **not** included; obtain them from their original releases and respect their licenses.
- `results/`: the output text files cited in the manuscript.
- `RESULTS.md`, `MODEL.md`, `LITERATURE_PARAMS.md`: analysis records (in Korean), kept as the audit trail of every number and correction.

## Requirements
Python 3.10+, numpy, scipy, pandas, requests, mwparserfromhell, datasets. Language-model calls go through the OpenRouter API (set `OPENROUTER_API_KEY`); results from judge calls can differ slightly across runs.

## Running
`python3 collect_entities.py` / `collect_factscore.py` (build entity list), `python3 generate.py --model <id> --task bio|summ`, `python3 label_sent.py --gen data/<file>.jsonl`, `bash run_ext.sh` (cross-model runs), then `analyze_sent.py`, `alloc_eval.py`, `crossmodel.py`, `public_human_eval.py`, `is_model*.py`. Each script writes to `results/`. Generation and labeling scripts skip items already present.

## Not included
Human-label files (`data/human/`), the Wikipedia-derived entity file, API keys.
