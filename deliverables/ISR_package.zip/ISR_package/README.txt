ISR submission package
======================
ISR_manuscript.pdf   Manuscript (PDF, equations rendered)
ISR_manuscript.docx  Manuscript (Word; equations are native Word equations)
ISR_manuscript.md    Manuscript source (Markdown + LaTeX math; convert with pandoc)
figures/             Figures 1-5 (JPEG/PNG)
code/                Scripts used for all numerical results (see code/README.md)
results/             Per-seed JSON outputs, summaries, parameter-grid output
  seeds_gpu/            GSM8K, 160M-0.5B pairs, 5 seeds
  seeds_large_gpu/      GSM8K, 1.4B-3B pairs, 5 seeds (4 for Qwen2.5-3B)
  tasks_small_gpu/      DialogSum and SQL, 160M-0.5B pairs, 5 seeds
  tasks_large_gpu/      DialogSum and SQL, Pythia-1.4B +70k and Qwen2.5-1.5B, 3 seeds
  all_tasks_summary.json  24 pair-task cells (Table C.3)
  sensitivity.*         Parameter-grid / distribution check (Appendix F)
Convert the Markdown to Word:  pandoc ISR_manuscript.md -o ISR_manuscript.docx --resource-path=.
