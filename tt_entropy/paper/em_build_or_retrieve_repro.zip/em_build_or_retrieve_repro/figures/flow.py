import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
plt.rcParams.update({"font.family": "Liberation Sans", "font.size": 7.5})
fig, ax = plt.subplots(figsize=(6.5, 4.6), dpi=600); ax.set_xlim(-1, 101); ax.set_ylim(0, 72); ax.axis("off")
def box(x, y, w, h, text, kind="step"):
    fc = {"step": "white", "q": "#eef3fb", "end": "#f2f2f2"}[kind]
    ec = "#1f5fbf" if kind == "q" else "0.3"
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0.4,rounding_size=1.5", fc=fc, ec=ec, lw=1))
    ax.text(x, y, text, ha="center", va="center", wrap=True)
def arrow(x1, y1, x2, y2, label=None, lx=0, ly=0):
    ax.annotate("", (x2, y2), (x1, y1), arrowprops=dict(arrowstyle="-|>", color="0.25", lw=0.9))
    if label: ax.text((x1 + x2) / 2 + lx, (y1 + y2) / 2 + ly, label, fontsize=7.5, color="0.2", ha="center")
box(50, 66, 54, 7, "New client: compute the type-token ratio\nof its past replies (P5)", "step")
box(50, 53, 64, 7, "Expected volume above the break-even?\n(about 1,200 requests; more with maintenance) (P1)", "q")
box(19, 39, 34, 8, "Serve with retrieval (RAG)\nRefresh the index regularly", "end")
box(70, 39, 50, 8, "Build a minimal adapter (rank 1) (P2)\nPrioritize low-diversity clients", "step")
box(70, 25, 54, 8, "Drift detected, or base model upgraded?\nAnnual value above the threshold v*? (P4)", "q")
box(44, 9, 28, 8, "Retrain the adapter", "end")
box(80, 9, 35, 8, "Keep the stale adapter\n(ahead for about 12 weeks) (P3)", "end")
arrow(50, 62.3, 50, 56.7)
arrow(36, 49.3, 22, 43.2, "no", -3, 1)
arrow(62, 49.3, 68, 43.2, "yes", 4, 1)
arrow(70, 34.8, 70, 29.2)
arrow(58, 20.8, 46, 13.2, "yes", -3, 1)
arrow(77, 20.8, 80, 13.2, "no", 4, 1)
fig.savefig("Fig3.png", bbox_inches="tight"); print("ok")
