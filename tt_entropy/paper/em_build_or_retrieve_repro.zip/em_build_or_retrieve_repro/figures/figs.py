import json, glob, sys
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
plt.rcParams.update({"font.family": "Liberation Sans", "font.size": 8})
def box(ax, x, y, w, h, text, fc="white", ec="0.2", ls="-"):
    ax.add_patch(FancyBboxPatch((x - w/2, y - h/2), w, h, boxstyle="round,pad=0.3,rounding_size=1.2", fc=fc, ec=ec, lw=0.9, ls=ls))
    ax.text(x, y, text, ha="center", va="center")
def arr(ax, x1, y1, x2, y2, lab=None, dx=0, dy=1.5, ls="-"):
    ax.annotate("", (x2, y2), (x1, y1), arrowprops=dict(arrowstyle="-|>", color="0.2", lw=0.8, ls=ls))
    if lab: ax.text((x1+x2)/2 + dx, (y1+y2)/2 + dy, lab, ha="center", fontsize=7.5, style="italic")
# Fig 1 research model
fig, ax = plt.subplots(figsize=(6.7, 3.4), dpi=600); ax.set_xlim(0, 100); ax.set_ylim(0, 52); ax.axis("off")
box(ax, 14, 47, 24, 6, "Client traits\n(reply diversity)")
box(ax, 14, 36, 24, 6, "Asset capacity and\nsophistication")
box(ax, 14, 18, 24, 9, "Personalization mode\n(asset vs. service)", fc="0.93")
box(ax, 50, 36, 24, 8, "Personalization value\n(quality of replies)")
box(ax, 50, 12, 24, 8, "Cost\n(fixed vs. variable)")
box(ax, 86, 24, 25, 11, "Provider decisions:\nmode per client and\nmaintenance policy", fc="0.93")
box(ax, 50, 49, 22, 4.5, "Time since build", ls="--")
box(ax, 70, 3, 18, 5, "Client volume", ls="--")
arr(ax, 26, 46, 38, 39.5); ax.text(31, 44.5, "P5", fontsize=7.5, style="italic")
arr(ax, 26, 36, 38, 36, ls="--"); ax.text(32, 33.2, "P2 (no effect)", fontsize=6.5, style="italic", ha="center")
arr(ax, 26, 21, 38, 33); ax.text(30, 28, "P2", fontsize=7.5, style="italic")
arr(ax, 26, 15, 38, 12.5); ax.text(31, 15.2, "P1", fontsize=7.5, style="italic")
arr(ax, 50, 46.7, 50, 40.2); ax.text(51.5, 42.6, "P3", fontsize=7.5, style="italic")
arr(ax, 62, 35, 73.5, 27); arr(ax, 62, 13, 73.5, 21)
arr(ax, 70, 5.5, 70, 17.5); ax.text(71.5, 9.5, "P1, P4", fontsize=7.5, style="italic")
fig.savefig("Fig1.png", bbox_inches="tight"); plt.close(fig)
# Fig 2 obsolescence
rows = [json.load(open(p)) for p in sorted(glob.glob(sys.argv[1] + "/*.json"))]
W = [str(i) for i in range(2, 9)]; m = lambda w, k: np.mean([r["weeks"][w][k] for r in rows])
ad = [m(w, "lora_stale_rel") for w in W]; rg = [m(w, "rag_fresh_rel") for w in W]
ip = m("in-period", "lora_stale_rel"); re_ = m("8", "lora_fresh_rel"); x = list(range(2, 9))
fig, ax = plt.subplots(figsize=(6.7, 3.3), dpi=600)
ax.plot(x, ad, "-o", color="#1f4e99", ms=4, lw=1.6, label="Adapter, not retrained (trained on weeks 0–1)")
ax.plot(x, rg, "--s", color="0.45", ms=4, lw=1.6, label="Retrieval with weekly refreshed index")
ax.plot([1], [ip], "o", mfc="white", mec="#1f4e99", ms=6, label=f"Adapter in training period ({ip:.3f})")
ax.plot([8], [re_], "x", color="black", ms=7, mew=1.8, label=f"Adapter retrained on weeks 6–7 ({re_:.3f})")
for ys in (ad[-1], rg[-1]): ax.annotate(f"{ys:.3f}", (8, ys), xytext=(6, -3), textcoords="offset points", fontsize=7.5)
ax.set_xticks(range(1, 9)); ax.set_xticklabels(["train"] + [str(i) for i in x]); ax.set_xlim(0.6, 8.7); ax.set_ylim(0.28, 0.53)
ax.set_xlabel("Week of the corpus"); ax.set_ylabel("Mean relative gain (35 brands)")
for s in ("top", "right"): ax.spines[s].set_visible(False)
ax.legend(frameon=False, fontsize=7.5, loc="upper right"); fig.tight_layout(); fig.savefig("Fig2.png"); plt.close(fig)
print("ok")
