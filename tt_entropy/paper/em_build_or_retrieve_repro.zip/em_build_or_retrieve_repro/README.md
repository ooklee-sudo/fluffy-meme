# Reproduction package

**Build or Retrieve? Personalization Strategies for Multi-Tenant Generative AI Services**
(manuscript submitted to *Electronic Markets*)

This package contains the code, the preregistration documents, the result files that the manuscript's
analyses read, and the commands for every study. It contains no tweet text: the corpus is downloaded from
Kaggle (section 2), and the generated replies, customer messages and style examples have been removed from
the H5 result files.

## Contents

| Path | What it is |
| --- | --- |
| `*.py` | All code: adapters (`tt.py`, `adapters.py`), data preparation (`data.py`), training and evaluation (`phase1.py`, `phase2.py`), retrieval baselines (`baselines.py`), serving benchmark (`bench_econ.py`), drift study (`drift.py`), reply generation and LLM judging (`gen_replies.py`, `judge.py`), analyses (`analyze_*.py`), robustness analyses (`analyze_robustness.py`), the 100-client case (`case_portfolio.py`), the real-options model (`real_options.py`, `real_options_econ.py`) and unit tests (`test_*.py`) |
| `h5_brands.txt`, `h7_brands.txt` | Brands of the preregistered studies |
| `preregistrations/` | Preregistration of H5, H7 and H10 with its results section; the H2 preregistration that fixed the learning rates of LoRA and VeRA; the record of the exploratory economics studies (E1, E2, E4) |
| `results/h5_gen/` | Per-brand likelihood gains and reply traits for the 50 H5 brands (text removed) |
| `results/h5_judge.jsonl` | All 6,373 LLM-judge verdicts (no text, only the judges' categorical answers) |
| `results/h7_drift/` | Weekly relative gains for the 35 H7 brands |
| `results/real_options_econ.json` | Output of the maintenance-policy calibration |
| `figures/` | Figures 1–3 and the scripts that draw them |
| `data/twcs.csv.sha256` | SHA-256 of the data file used |
| `LICENSE`, `NOTICE`, `DATA_LICENSE.md` | MIT licence for the code; Apache-2.0 exception for the QuanTA port; data licence |

## 1. Environment

Sections 2 and 3 run on any computer without a GPU. Section 4 needs Python 3.10 or later and one CUDA GPU with
at least 8 GB of memory (all runs used an NVIDIA RTX 5070 Laptop GPU with PyTorch 2.11 and CUDA 12.8).

```bash
pip install torch transformers accelerate datasets numpy scipy pandas matplotlib
python test_tt.py && python test_adapters.py
```

The base model, `Qwen/Qwen2.5-1.5B`, is downloaded from Hugging Face on first use.

## 2. Data

Download `twcs.csv` from Kaggle (Customer Support on Twitter, thoughtvector, CC BY-NC-SA 4.0):
https://www.kaggle.com/datasets/thoughtvector/customer-support-on-twitter. Put it in `data/`, check it and
convert it:

```bash
cd data && sha256sum -c twcs.csv.sha256 && cd ..
python data.py twcs data/twcs.csv data/twcs_pairs.jsonl 200
```

This writes `data/twcs_pairs.jsonl` (1,259,128 pairs from 106 brands) and `data/twcs_pairs_time.jsonl`
(the same pairs with timestamps, used by the drift study).

## 3. Reproducing the reported statistics from the included results (CPU, minutes)

```bash
python analyze_h5.py results/h5_gen results/h5_judge.jsonl     # H5 (reply quality) and H10 (targeting)
python analyze_h7.py results/h7_drift                           # H7 (asymmetric obsolescence)
python analyze_robustness.py data/twcs_pairs.jsonl             # robustness analyses (Tables 7-10)
python real_options_econ.py --pairs data/twcs_pairs.jsonl      # maintenance policy (Table 6, Appendix A)
python case_portfolio.py data/twcs_pairs.jsonl 1               # 100-client case, observed client sizes (Table 12)
python case_portfolio.py data/twcs_pairs.jsonl 0.1             # 100-client case, ten times smaller clients
cd figures && python figs.py ../results/h7_drift && python flow.py && cd ..   # Figures 1-3
```

The commands that need `data/twcs_pairs.jsonl` use it only to count each brand's replies (its volume).

## 4. Re-running the experiments (GPU)

**Exploratory value and cost studies (E1, E2).** These use the 31 brands and the LoRA and VeRA runs of the
companion comparison (`preregistrations/PREREGISTRATION_H2.md`, learning rates LoRA 3e-3, VeRA 3e-2):

```bash
python phase2.py --exclude-dir results/phase1,results/phase1_confirm,results/phase1_value --n-tenants 31 --lrs tt=1e-3,lora=3e-3,vera=3e-2 --seed 0 --out results/phase2_s0
python baselines.py --tenants-from results/phase2_s0 --out results/econ_e1
python analyze_econ_e1.py results/econ_e1 results/phase2_s0
python bench_econ.py --phase2 results/phase2_s0
```

The brand list of these studies depends on the brands used in earlier studies of the project (the
`--exclude-dir` folders); the 31 brands are listed in `preregistrations/PREREGISTRATION_H2.md`, section 3, and
can be passed directly with `--tenants`.

**Exploratory drift study (E4).**

```bash
python drift.py --n-brands 30 --out results/econ_e4
python analyze_drift.py results/econ_e4
```

**Preregistered studies (H5, H10, H7).**

```bash
python gen_replies.py --tenants-file h5_brands.txt --out results/h5_gen
python judge.py results/h5_gen --out results/h5_judge.jsonl --max-cost 10
python drift.py --tenants $(grep -v '^#' h7_brands.txt | paste -sd, -) --out results/h7_drift
```

`judge.py` calls the judges through OpenRouter (https://openrouter.ai) and needs an API key in the
`Authorization` header (edit `call()` in `judge.py`); judging all pairs cost about US$2.50. LLM outputs are
not fully deterministic even at temperature 0, so re-judging reproduces the verdicts closely but not exactly.
Generation takes about 2 minutes per brand and the drift study about 3 minutes per brand on the GPU above.

## Note on included results

The result files of the exploratory studies E1, E2 and E4 and of the 31-brand comparison runs are not yet
included in this version of the package; their summaries are recorded in `preregistrations/ECON_RESULTS.md`
and can be regenerated with the commands in section 4.

## Preregistration record

`preregistrations/PREREGISTRATION_H5_H7.md` was committed to the project repository, with the code, before
any data of H5, H7 or H10 were collected; the commit history timestamps it. Results and deviations (none)
were added after the runs.

## Licences

The code is released under the MIT License (`LICENSE`); the QuanTA module in `adapters.py` remains under the
Apache License 2.0 (`NOTICE`). The data are licensed CC BY-NC-SA 4.0 by their creator (`DATA_LICENSE.md`).
