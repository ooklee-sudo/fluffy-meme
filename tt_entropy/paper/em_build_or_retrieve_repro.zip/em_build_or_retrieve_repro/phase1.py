"""Phase 1 (H1): does a probe's entanglement entropy predict each tenant's capacity need?

For each tenant:
  1. L_none: held-out response NLL of the base model with no adapter
  2. Gradient probe (primary): the loss gradient w.r.t. each frozen weight W, summed over the training set,
     -> entanglement profile of every gradient matrix (no training, no initialization effects)
  3. TT probe (secondary): a short TT-adapter fine-tune -> entanglement of dW. Its non-final cores start
     random, so this profile partly reflects initialization; kept for comparison only.
  4. Sweep: a fine-tune at each bond dimension r in --ranks (early stopping on dev) -> held-out NLL L_r
  5. Capacity need = bond dimension at which the gain (L_none - L_r) reaches --frac of the best gain,
     interpolated in log2(r) between grid points (capacity_need_grid = the grid value)
One JSON per tenant goes to --out; reruns skip finished tenants. Then run: python analyze.py
--reprobe adds the gradient probe to finished tenants without re-running their sweep.

Usage:
  python phase1.py --tiny                                            # CPU smoke test, no downloads
  python phase1.py --data data/twcs_pairs.jsonl --n-tenants 10       # RTX 5070 Laptop (8 GB) defaults
"""
import argparse
import json
import math
import os
import random
import re
import time

import torch
import torch.nn.functional as F

from data import encode_tenant, features, load_jsonl, synthetic_tenants
from tt import (adapter_params, add_tt_adapters, bond_profile, get_state, matrix_profile, reset_adapters,
                set_state)


def get_args():
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    a.add_argument("--model", default="Qwen/Qwen2.5-1.5B")
    a.add_argument("--data", default="data/twcs_pairs.jsonl")
    a.add_argument("--tiny", action="store_true", help="random tiny Llama + synthetic tenants on CPU")
    a.add_argument("--out", default=None, help="default: results/phase1 (results/phase1_tiny with --tiny)")
    a.add_argument("--n-tenants", type=int, default=10)
    a.add_argument("--tenants", default="", help="comma-separated tenant names (overrides --n-tenants)")
    a.add_argument("--select", default="spread", choices=["spread", "largest"],
                   help="spread: evenly across the size ranking (default); largest: the biggest tenants")
    a.add_argument("--min-examples", type=int, default=440)
    a.add_argument("--n-train", type=int, default=320)
    a.add_argument("--n-dev", type=int, default=40, help="early-stopping split, disjoint from train and eval")
    a.add_argument("--n-eval", type=int, default=80)
    a.add_argument("--max-len", type=int, default=256)
    a.add_argument("--bs", type=int, default=4)
    a.add_argument("--lr", type=float, default=1e-3)
    a.add_argument("--steps", type=int, default=300, help="max steps per sweep run (early stopping on dev)")
    a.add_argument("--eval-every", type=int, default=50)
    a.add_argument("--rank-scale", default="rs", choices=["rs", "none"],
                   help="rs: scale the update by 1/sqrt(bond dimension), as in rank-stabilized LoRA")
    a.add_argument("--probe-steps", type=int, default=60)
    a.add_argument("--probe-rank", type=int, default=8)
    a.add_argument("--ranks", default="1,2,4,8,16")
    a.add_argument("--d", type=int, default=4, help="number of TT cores per adapter")
    a.add_argument("--targets", default="q_proj,v_proj")
    a.add_argument("--frac", type=float, default=0.9)
    a.add_argument("--energy", type=float, default=0.99)
    a.add_argument("--seed", type=int, default=0, help="data seed: which pairs go to train, dev and eval")
    a.add_argument("--seeds", default="", help="training seeds for the sweep, e.g. 0,1,2 (default: --seed); "
                   "gains are averaged over seeds before the capacity need is computed")
    a.add_argument("--probe-tokens", type=int, default=4000,
                   help="response-token budget for the gradient probe, equal for every tenant (0 = all training data)")
    a.add_argument("--exclude-dir", default="", help="skip tenants with results in these folders (comma-separated)")
    a.add_argument("--list-only", action="store_true", help="print the selected tenants and exit")
    a.add_argument("--dtype", default="bf16", choices=["bf16", "fp32"])
    a.add_argument("--no-ckpt", action="store_true", help="disable gradient checkpointing")
    a.add_argument("--reprobe", action="store_true",
                   help="for finished tenants, (re)compute the gradient probe and capacity need; no sweep")
    args = a.parse_args()
    if args.tiny:
        args.n_tenants, args.min_examples, args.n_train, args.n_dev, args.n_eval = 4, 0, 96, 32, 32
        args.steps, args.probe_steps, args.bs, args.ranks, args.dtype = 80, 30, 8, "1,2,4,8", "fp32"
        args.eval_every, args.probe_tokens = 20, 400
        args.lr = 1e-2
    if args.out is None:
        args.out = "results/phase1_tiny" if args.tiny else "results/phase1"
    return args


# ---------------------------------------------------------------- model
def load_model(args, device):
    from transformers import AutoModelForCausalLM, AutoTokenizer, LlamaConfig, LlamaForCausalLM

    if args.tiny:
        torch.manual_seed(0)
        cfg = LlamaConfig(vocab_size=64, hidden_size=64, intermediate_size=128, num_hidden_layers=2,
                          num_attention_heads=4, num_key_value_heads=4, max_position_embeddings=64)
        return LlamaForCausalLM(cfg).to(device), None, 0
    dtype = torch.bfloat16 if args.dtype == "bf16" else torch.float32
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(args.model, dtype=dtype).to(device)
    if not args.no_ckpt:
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    model.config.use_cache = False
    pad = tok.pad_token_id if tok.pad_token_id is not None else tok.eos_token_id
    return model, tok, pad


def collate(batch, pad, max_len, device):
    seqs = [(p + r)[:max_len] for p, r in batch]
    plen = [min(len(p), max_len) for p, _ in batch]
    n = max(map(len, seqs))
    ids = torch.full((len(seqs), n), pad, dtype=torch.long)
    lab = torch.full_like(ids, -100)
    att = torch.zeros_like(ids)
    for i, s in enumerate(seqs):
        ids[i, : len(s)] = torch.tensor(s)
        att[i, : len(s)] = 1
        lab[i, plen[i]: len(s)] = torch.tensor(s[plen[i]:])
    return ids.to(device), att.to(device), lab.to(device)


def response_nll(model, batch, pad, max_len, device):
    """Summed NLL over response tokens and their count; logits only at response positions (saves memory)."""
    ids, att, lab = collate(batch, pad, max_len, device)
    h = model.model(input_ids=ids, attention_mask=att).last_hidden_state[:, :-1]
    tgt = lab[:, 1:]
    m = tgt != -100
    logits = model.lm_head(h[m]).float()
    return F.cross_entropy(logits, tgt[m], reduction="sum"), int(m.sum())


@torch.no_grad()
def evaluate(model, data, args, pad, device):
    model.eval()
    tot, n = 0.0, 0
    for i in range(0, len(data), args.bs):
        s, k = response_nll(model, data[i: i + args.bs], pad, args.max_len, device)
        tot, n = tot + float(s), n + k
    return tot / max(n, 1)


def train(model, adapters, data, steps, args, pad, device, seed, dev=None):
    """AdamW with warmup and cosine decay. With `dev`, evaluates every --eval-every steps (step 0 = no update
    included) and restores the best checkpoint, so extra capacity cannot hurt through overfitting."""
    params = adapter_params(adapters)
    opt = torch.optim.AdamW(params, lr=args.lr, weight_decay=0.0)
    warm = max(1, steps // 10)
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: min(1.0, (s + 1) / warm) * 0.5 * (1 + math.cos(math.pi * min(s, steps) / steps)))
    rng = random.Random(seed)
    curve, best = [], None
    if dev is not None:
        best = (evaluate(model, dev, args, pad, device), 0, get_state(adapters))
        curve.append((0, best[0]))
    model.train()
    for step in range(1, steps + 1):
        s, k = response_nll(model, rng.sample(data, min(args.bs, len(data))), pad, args.max_len, device)
        (s / max(k, 1)).backward()
        torch.nn.utils.clip_grad_norm_(params, 1.0)
        opt.step()
        sched.step()
        opt.zero_grad(set_to_none=True)
        if dev is not None and (step % args.eval_every == 0 or step == steps):
            v = evaluate(model, dev, args, pad, device)
            curve.append((step, v))
            if v < best[0]:
                best = (v, step, get_state(adapters))
            model.train()
    if dev is None:
        return None
    set_state(adapters, best[2])
    return dict(best_step=best[1], best_dev_nll=best[0], dev_curve=curve)


def probe_summary(profiles, cap=None):
    """Average bond statistics over modules. Entropy is normalized by log of the largest rank the bond can
    hold (capped at `cap`, the probe's bond dimension, for the TT probe)."""
    bonds = [b for prof in profiles.values() for b in prof]
    lim = lambda b: min(cap, b["max_rank"]) if cap else b["max_rank"]
    norm = [b["entropy"] / math.log(lim(b)) for b in bonds if lim(b) > 1]
    mean = lambda key: sum(b[key] for b in bonds) / len(bonds)
    return dict(mean_entropy=mean("entropy"), max_entropy=max(b["entropy"] for b in bonds),
                mean_norm_entropy=sum(norm) / max(len(norm), 1),
                mean_rank_at_energy=mean("rank_at_energy"), mean_rank_at_90=mean("rank_at_90"))


def token_budget(data, budget):
    """Leading examples holding exactly `budget` response tokens (the last one cut short); 0 = all."""
    if not budget:
        return data, sum(len(r) for _, r in data)
    out, n = [], 0
    for p, r in data:
        if n >= budget:
            break
        r = r[: budget - n]
        out.append((p, r))
        n += len(r)
    return out, n


def grad_probe(model, adapters, data, args, pad, device):
    """Sum the loss gradient w.r.t. each wrapped base weight over a fixed response-token budget of `data`
    (adapters at zero), then profile it. A fixed budget keeps the gradient noise level equal across tenants:
    with more tokens, noise averages out and the entropy falls for reasons unrelated to the tenant."""
    data, n_tokens = token_budget(data, args.probe_tokens)
    reset_adapters(adapters, 1)  # last core zero -> the model is exactly the base model
    ws = {k: ad.base.weight for k, ad in adapters.items()}
    for w in ws.values():
        w.requires_grad_(True)
    acc = {k: torch.zeros(w.shape, dtype=torch.float32, device=w.device) for k, w in ws.items()}
    model.train()  # needed for gradient checkpointing; Qwen and Llama use no dropout
    for i in range(0, len(data), args.bs):
        s, k = response_nll(model, data[i: i + args.bs], pad, args.max_len, device)
        s.backward()
        for key, w in ws.items():
            acc[key] += w.grad.float()
            w.grad = None
        for c in adapter_params(adapters):
            c.grad = None
    for w in ws.values():
        w.requires_grad_(False)
    bonds = {k: bond_profile(acc[k], ad.out_f, ad.in_f, args.energy) for k, ad in adapters.items()}
    mats = {k: matrix_profile(acc[k], args.energy) for k in adapters}
    msum = dict(
        mean_entropy=sum(m["entropy"] for m in mats.values()) / len(mats),
        mean_norm_entropy=sum(m["entropy"] / math.log(m["max_rank"]) for m in mats.values()) / len(mats),
        mean_rank_at_energy=sum(m["rank_at_energy"] for m in mats.values()) / len(mats),
        mean_rank_at_90=sum(m["rank_at_90"] for m in mats.values()) / len(mats))
    del acc
    return dict(n_examples=len(data), n_tokens=n_tokens, budget=args.probe_tokens,
                budget_met=(not args.probe_tokens) or n_tokens >= args.probe_tokens,
                summary=probe_summary(bonds), matrix_summary=msum, modules=bonds)


def capacity_need(sweep, frac):
    """(interpolated need, grid need): where the gain first reaches frac x best, in log2(r)."""
    sw = sorted(sweep, key=lambda r: r["rank"])
    best = max(r["gain"] for r in sw)
    if best <= 0:
        return None, None
    t = frac * best
    i = next(j for j, r in enumerate(sw) if r["gain"] >= t)
    if i == 0:
        return float(sw[0]["rank"]), sw[0]["rank"]
    (r0, g0), (r1, g1) = (sw[i - 1]["rank"], sw[i - 1]["gain"]), (sw[i]["rank"], sw[i]["gain"])
    x = math.log2(r0) + (t - g0) / (g1 - g0) * (math.log2(r1) - math.log2(r0))
    return 2 ** x, r1


# ---------------------------------------------------------------- main
def main():
    args = get_args()
    if not args.tiny and not os.path.exists(args.data):
        raise SystemExit(f"data file not found: {args.data}\n"
                         "Make it first (README step 3): python data.py twcs data/twcs.csv data/twcs_pairs.jsonl 200")
    device = "cuda" if torch.cuda.is_available() else "cpu"
    os.makedirs(args.out, exist_ok=True)

    if args.tiny:
        raw = synthetic_tenants(8, args.n_train + args.n_dev + args.n_eval, vocab=64)
    else:
        raw = load_jsonl(args.data)
    if args.tenants:
        names = args.tenants.split(",")
    else:
        excl = set()
        for d in filter(None, args.exclude_dir.split(",")):
            if not os.path.isdir(d):
                raise SystemExit(f"--exclude-dir: folder not found: {d}")
            for f in os.listdir(d):
                if f.endswith(".json"):
                    with open(os.path.join(d, f)) as fh:
                        excl.add(json.load(fh)["tenant"])
        if excl:
            print(f"excluding {len(excl)} tenants found in {args.exclude_dir}")
        names = sorted([t for t, v in raw.items() if len(v) >= args.min_examples and t not in excl],
                       key=lambda t: -len(raw[t]))
        k = min(args.n_tenants, len(names))
        if args.select == "spread" and k > 1:
            names = [names[round(i * (len(names) - 1) / (k - 1))] for i in range(k)]
        else:
            names = names[:k]
        names = sorted(names)
    ranks = [int(r) for r in args.ranks.split(",")]
    seeds = [int(s) for s in args.seeds.split(",")] if args.seeds else [args.seed]
    print(f"{len(names)} tenants ({args.select}): {', '.join(names)}\nbond dimensions {ranks}, training seeds {seeds}")
    if args.list_only:
        return
    model, tok, pad = load_model(args, device)
    adapters = add_tt_adapters(model, targets=tuple(args.targets.split(",")), ranks=args.probe_rank, d=args.d,
                               rank_scale=args.rank_scale)
    print(f"device={device}  adapted modules={len(adapters)}  e.g. {next(iter(adapters))}: "
          f"out={next(iter(adapters.values())).out_f} in={next(iter(adapters.values())).in_f}")


    for ti, name in enumerate(names):
        path = os.path.join(args.out, re.sub(r"[^\w.-]", "_", name) + ".json")
        if os.path.exists(path) and not args.reprobe:
            print(f"[{ti + 1}/{len(names)}] {name}: done, skipping")
            continue
        t0 = time.time()
        pairs = list(raw[name])
        random.Random(args.seed).shuffle(pairs)
        n_all = args.n_train + args.n_dev + args.n_eval
        enc = pairs[:n_all] if args.tiny else encode_tenant(pairs[:n_all], tok, args.max_len)
        tr, dv = enc[: args.n_train], enc[args.n_train: args.n_train + args.n_dev]
        ev = enc[args.n_train + args.n_dev: n_all]

        if os.path.exists(path):  # --reprobe: keep the sweep, add the gradient probe
            with open(path) as f:
                res = json.load(f)
            if res["n_train"] != len(tr):
                raise SystemExit(f"{name}: saved n_train {res['n_train']} != {len(tr)}; use the original settings")
            if "grad_probe" in res and "budget" not in res["grad_probe"]:
                res["grad_probe_all_tokens"] = res.pop("grad_probe")  # keep the earlier full-data probe
            res["grad_probe"] = grad_probe(model, adapters, tr, args, pad, device)
            res["capacity_need"], res["capacity_need_grid"] = capacity_need(res["sweep"], args.frac)
            with open(path, "w") as f:
                json.dump(res, f, indent=1)
            g = res["grad_probe"]["summary"]
            print(f"[{ti + 1}/{len(names)}] {name}: grad norm-entropy={g['mean_norm_entropy']:.3f} "
                  f"need={res['capacity_need']:.2f}  ({(time.time() - t0) / 60:.1f} min)")
            continue

        reset_adapters(adapters, args.probe_rank)  # last core zero -> no update
        nll_none = evaluate(model, ev, args, pad, device)
        gprobe = grad_probe(model, adapters, tr, args, pad, device)

        torch.manual_seed(args.seed)
        reset_adapters(adapters, args.probe_rank)
        train(model, adapters, tr, args.probe_steps, args, pad, device, args.seed)
        profiles = {k: bond_profile(ad.delta(), ad.out_f, ad.in_f, args.energy) for k, ad in adapters.items()}
        probe = dict(rank=args.probe_rank, steps=args.probe_steps, nll=evaluate(model, ev, args, pad, device),
                     summary=probe_summary(profiles, cap=args.probe_rank), modules=profiles)

        runs = {s: [] for s in seeds}
        for s in seeds:
            for r in ranks:
                torch.manual_seed(s)
                reset_adapters(adapters, r)
                ts = time.time()
                es = train(model, adapters, tr, args.steps, args, pad, device, s, dev=dv)
                nll = evaluate(model, ev, args, pad, device)
                runs[s].append(dict(rank=r, nll=nll, gain=nll_none - nll, seconds=time.time() - ts,
                                    trainable_params=sum(ad.n_params() for ad in adapters.values()), **es))
                print(f"    seed {s} r={r:<3d} nll={nll:.4f} gain={nll_none - nll:+.4f}  "
                      f"best step {es['best_step']}/{args.steps}")
        sweep = []  # gains averaged over seeds
        for i, r in enumerate(ranks):
            rs = [runs[s][i] for s in seeds]
            sweep.append(dict(rank=r, nll=sum(x["nll"] for x in rs) / len(rs), gain=sum(x["gain"] for x in rs) / len(rs),
                              gains=[x["gain"] for x in rs], trainable_params=rs[0]["trainable_params"],
                              seconds=sum(x["seconds"] for x in rs)))
        need, need_grid = capacity_need(sweep, args.frac)
        need_by_seed = [capacity_need(runs[s], args.frac)[0] for s in seeds]
        res = dict(tenant=name, n_train=len(tr), n_dev=len(dv), n_eval=len(ev), features=features(tr),
                   nll_none=nll_none, grad_probe=gprobe, probe=probe, sweep=sweep, capacity_need=need,
                   capacity_need_grid=need_grid, capacity_need_by_seed=need_by_seed,
                   runs={str(s): v for s, v in runs.items()}, seeds=seeds, seconds=time.time() - t0, config=vars(args))
        with open(path, "w") as f:
            json.dump(res, f, indent=1)
        g = gprobe["summary"]
        print(f"[{ti + 1}/{len(names)}] {name}: none={nll_none:.4f} grad norm-entropy={g['mean_norm_entropy']:.3f} "
              f"need={need if need is None else round(need, 2)}  ({res['seconds'] / 60:.1f} min)")


if __name__ == "__main__":
    main()
