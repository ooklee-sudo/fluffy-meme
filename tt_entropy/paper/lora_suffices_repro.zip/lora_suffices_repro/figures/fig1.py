import json, glob, os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
R = sys.argv[2] if len(sys.argv) > 2 else "results"
def load(d, tag=""):
    out = {}
    for p in glob.glob(os.path.join(R, d, "*.json")):
        for run in json.load(open(p))["runs"]:
            out.setdefault(run["config"] + tag, []).append((run["params"], run["rel_gain"]))
    return out
rows = load("h2b_main"); rows.update(load("h2b_tt_d3", "@3")); rows.update(load("h2b_tt_d5", "@5"))
name = {"lora:1": "LoRA r=1", "lora:4": "LoRA r=4", "quanta:5": "QuanTA, 5 axes", "quanta:4": "QuanTA, 4 axes",
        "tt:2": "TT r=2, 4 cores", "tt:10": "TT r=10, 4 cores", "tt:2@3": "TT r=2, 3 cores", "tt:10@3": "TT r=10, 3 cores",
        "tt:2@5": "TT r=2, 5 cores", "tt:10@5": "TT r=10, 5 cores"}
pts = {c: (v[0][0], np.mean([g for _, g in v])) for c, v in rows.items()}
for c, (p, g) in sorted(pts.items(), key=lambda x: x[1][0]): print(f"{c:10} {p:>9,} {g:.4f} n={len(rows[c])}")
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})
fig, ax = plt.subplots(figsize=(6.3, 3.6), dpi=300)
ref = pts["lora:1"][1]
ax.axhline(ref, ls="--", lw=0.8, color="0.5")
ax.text(1.05e4, ref + 0.002, f"LoRA r=1 level ({ref:.3f})", color="0.35", fontsize=8)
for c, (p, g) in pts.items():
    if c.startswith("lora"):
        ax.scatter(p, g, s=36, color="#1f5fbf", zorder=3)
        ax.annotate(name[c], (p, g), textcoords="offset points", xytext=(0, 7), ha="center", fontsize=8)
    elif c.startswith("quanta"):
        ax.scatter(p, g, s=36, marker="D", facecolor="0.75", edgecolor="0.3", zorder=3)
    else:
        ax.scatter(p, g, s=30, color="0.6", zorder=3)
for c in ("tt:2@5", "tt:2", "tt:2@3"):
    p, g = pts[c]; ax.annotate(name[c], (p, g), textcoords="offset points", xytext=(7, -3), fontsize=8, color="0.3")
big = [g for c, (p, g) in pts.items() if p > 1e5 and not c.startswith("lora")]
ax.annotate(f"TT r=10 (3, 4, 5 cores) and QuanTA (4, 5 axes): {min(big):.3f}–{max(big):.3f}",
            (2.3e5, min(big) - 0.004), xytext=(9.5e5, min(big) - 0.016), ha="right", fontsize=8, color="0.3")
ax.set_xscale("log"); ax.set_xlim(1e4, 1.1e6); ax.set_ylim(0.30, 0.435)
ax.set_xlabel("Trainable parameters per brand (log scale)"); ax.set_ylabel("Mean relative gain")
ax.scatter([], [], color="#1f5fbf", label="LoRA"); ax.scatter([], [], color="0.6", label="Tensor train (TT)")
ax.scatter([], [], marker="D", facecolor="0.75", edgecolor="0.3", label="QuanTA")
ax.legend(loc="lower right", frameon=False, fontsize=8)
for s in ("top", "right"): ax.spines[s].set_visible(False)
fig.tight_layout(); fig.savefig(sys.argv[1]); print("saved")
