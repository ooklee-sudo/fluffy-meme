# Reproduction package

**Low-Rank Adaptation Suffices: A Preregistered Comparison of Tensor-Network Adapters for Personalizing
Large Language Models** (Ook Lee and Kyung-Kwon Eo, Hanyang University)

This package holds the code, the preregistration documents, the per-brand result files that the paper's
analyses read, and the commands for every study. It does not contain tweet text. The dataset is
downloaded from Kaggle (step 2).

## Contents

| Path | What it is |
| --- | --- |
| `*.py` | All code: adapters (`tt.py`, `adapters.py`), data preparation (`data.py`, `data_tasks.py`), runs (`phase1.py`, `phase2.py`, `phase3.py`), analyses (`analyze*.py`, `explore.py`, `mechanism.py`, `decision.py`), latency benchmark (`bench.py`), unit tests (`test_*.py`) |
| `h2b_brands.txt` | The 16 brands of H2b |
| `preregistrations/` | The preregistration of each study with its results section, the pilot stop rule, and the exploratory follow-up of H1′ |
| `results/` | Per-brand JSON results: Phase 1 exploration (`phase1`), H1 (`phase1_confirm`), H1′ (`phase1_value`), H2b tuning and runs (`h2b_*`) |
| `figures/` | Figure 1 and the script that draws it from `results/h2b_*` |
| `data/twcs.csv.sha256` | SHA-256 of the data file used |
| `DATA_LICENSE.md` | Source and licence of the data, and attribution for the QuanTA port |

## 1. Environment

Python 3.10 or later and one CUDA GPU with at least 8 GB of memory (all runs used an NVIDIA RTX 5070 Laptop
GPU, 8 GB, with PyTorch 2.11 and CUDA 12.8). Install:

```bash
pip install torch transformers accelerate datasets numpy scipy pandas matplotlib
```

Check the installation on the CPU (no GPU or data needed):

```bash
python test_tt.py && python test_adapters.py && python phase1.py --tiny && python phase2.py --tiny
```

The base model, `Qwen/Qwen2.5-1.5B`, is downloaded from Hugging Face on first use.

## 2. Data

Download `twcs.csv` from Kaggle (Customer Support on Twitter, thoughtvector, CC BY-NC-SA 4.0):
https://www.kaggle.com/datasets/thoughtvector/customer-support-on-twitter. Put it in `data/`, check it and
convert it to customer/reply pairs:

```bash
cd data && sha256sum -c twcs.csv.sha256 && cd ..
python data.py twcs data/twcs.csv data/twcs_pairs.jsonl 200
```

This gives 1,259,128 pairs from 106 brands. Every study draws its brands from this file with a fixed rule,
so the brand lists below are reproduced exactly.

## 3. Reproducing the analyses from the included results (minutes, CPU)

```bash
python analyze.py results/phase1_confirm          # H1 primary test
python analyze_value.py results/phase1_value      # H1' primary test
python mechanism.py && python decision.py         # exploratory follow-ups of H1' (SVD control, decision value)
python analyze_tune.py results/h2b_tune           # H2b learning-rate choice for QuanTA
python analyze_h2b.py results/h2b_main results/h2b_tt_d3 results/h2b_tt_d5   # H2b primary test
python figures/fig1.py figures/fig1.png results   # Figure 1
```

## 4. Re-running the experiments (GPU)

Times are for the laptop GPU above, where measured. Each command skips brands whose result file already exists, so runs can
be resumed.

**Exploration and H1 / H1′ (Phase 1)**

```bash
python phase1.py --n-tenants 10 --out results/phase1
python phase1.py --n-tenants 10 --reprobe --out results/phase1   # adds the 4000-token gradient probe
python phase1.py --exclude-dir results/phase1 --n-tenants 30 --seeds 0,1 --out results/phase1_confirm
python phase1.py --exclude-dir results/phase1,results/phase1_confirm --n-tenants 30 --seeds 0,1 --out results/phase1_value
```

**H2 (31 brands, two seeds, about 10 h per seed)**

```bash
python phase2.py --tune --tenants-from results/phase1 --out results/phase2_tune
python analyze_tune.py results/phase2_tune
python phase2.py --exclude-dir results/phase1,results/phase1_confirm,results/phase1_value --n-tenants 31 --lrs tt=1e-3,lora=3e-3,vera=3e-2 --seed 0 --out results/phase2_s0
python phase2.py --exclude-dir results/phase1,results/phase1_confirm,results/phase1_value --n-tenants 31 --lrs tt=1e-3,lora=3e-3,vera=3e-2 --seed 1 --out results/phase2_s1
python analyze_h2.py results/phase2_s0 results/phase2_s1
```

The tuning rule extends a grid whose best value lies at its edge (see `preregistrations/PREREGISTRATION_H2.md`,
section 8); the learning rates above are the final choices.

**H2b (16 brands, about 3 h)**

```bash
python phase2.py --tune --tenants-from results/phase1 --configs quanta:4 --tune-lrs quanta=3e-4/1e-3/3e-3/1e-2 --out results/h2b_tune
B=$(grep -v '^#' h2b_brands.txt | paste -sd, -)
python phase2.py --tenants $B --configs lora:1,lora:4,quanta:5,quanta:4,tt:2,tt:10 --lrs lora=3e-3,tt=1e-3,quanta=1e-3 --out results/h2b_main
python phase2.py --tenants $B --d 3 --configs tt:2,tt:10 --lrs tt=1e-3 --out results/h2b_tt_d3
python phase2.py --tenants $B --d 5 --configs tt:2,tt:10 --lrs tt=1e-3 --out results/h2b_tt_d5
```

**Knowledge-injection pilot and H4 (per H4 fact set: about 81 min for TT r=31 and 29 min for LoRA r=16)**

```bash
python phase3.py --task facts --n-facts 500 && python phase3.py --task facts --n-facts 2000 && python phase3.py --task facts --n-facts 8000 && python phase3.py --task math --n-math 5000
python analyze_pilot.py
python phase3.py --task facts --n-facts 8000 --task-seed 100 --configs lora:16,tt:31 --tune-lrs lora=1e-3/3e-3/1e-2,tt=3e-4/1e-3/3e-3 --steps 2000 --out results/h4_tune
python analyze_h4.py tune results/h4_tune
for s in 1 2 3 4 5 6; do python phase3.py --task facts --n-facts 8000 --task-seed $s --configs lora:16,tt:31,lora:32 --lrs tt=1e-3,lora=1e-3 --steps 6000 --out results/h4 || break; done
python analyze_h4.py test results/h4
```

The pilot (`phase3.py`) needs the MetaMathQA and GSM8K datasets from Hugging Face for its math task only.

## Preregistration record

Each document in `preregistrations/` was committed to the project repository, with the code, before any data
of its study were collected; the commit history timestamps it. Results and any deviations (there were none)
were added to each document after its run.

## Licences

The data are licensed CC BY-NC-SA 4.0 by their creator (see `DATA_LICENSE.md`). The QuanTA module in
`adapters.py` is a port of https://github.com/quanta-fine-tuning/quanta (Apache-2.0).
