# Replication package

"Switching the Ruler: Measurement-System Risk and Real Options in Generative AI Maintenance"

| Folder | Reproduces | Requirements |
| --- | --- | --- |
| `gsm8k_judge_search/` | Section 7.2: best-of-N selection (Table 4) and judge-guided rewriting (Table 5), with all per-question raw data | Python 3.10+, `requests`, `numpy`, `scipy`; an OpenRouter API key only to re-run the model calls |
| `appendix_numerics/` | Section 4 ("Valuing the option") and Appendix A, Steps 4-5: exercise premium and value of the switch-the-ruler option (Proposition 3) | Python 3, standard library only |

## Quick check without model calls

The raw data are included, so Tables 4 and 5 can be recomputed directly:

```bash
pip install numpy scipy
cd gsm8k_judge_search
python analyze.py          # writes results/summary.json
cd ../appendix_numerics
python premium_and_switch_option.py
```

`analyze.py` uses fixed random seeds; bootstrap intervals and best-of-N expectations reproduce to the reported precision.

## Re-running the model calls

```bash
export OPENROUTER_API_KEY=...
cd gsm8k_judge_search
python run_gsm8k.py bon
python run_gsm8k.py rewrite
python analyze.py
```

Model outputs are sampled at temperature 1 and served by third-party providers, so a re-run will not match the included raw data exactly. See `gsm8k_judge_search/README.md` for the design.

## Data

- `results/gsm8k_test.jsonl`: GSM8K test set (Cobbe et al. 2021, MIT License), as downloaded.
- `results/bon_raw.jsonl`: 200 questions x 32 policy answers, each with judge score, correctness, length, and serving provider.
- `results/rewrite_init.jsonl`: the shared round-0 answer for each question.
- `results/rewrite_raw.jsonl`: one record per question, judge, and arm, with the full six-round history.
