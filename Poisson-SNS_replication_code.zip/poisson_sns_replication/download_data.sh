#!/usr/bin/env bash
# Downloads the public data used in Study 4 into ./data and extracts what the scripts need.
set -e
mkdir -p data/bsky && cd data
for i in 0 1 2 3 4 5 6; do
  curl -L -o bsky/s$i.parquet "https://huggingface.co/datasets/midwestern-simulation/12.1m_bluesky_posts/resolve/main/data/train-0000$i-of-00007.parquet"
done
for s in money law workplace; do
  curl -L -o $s.7z "https://archive.org/download/stackexchange/$s.stackexchange.com.7z"
  python3 -c "import py7zr,os,sys; s=sys.argv[1]; os.makedirs(s,exist_ok=True); py7zr.SevenZipFile(s+'.7z').extract(path=s,targets=['Posts.xml','Comments.xml'])" $s
done
