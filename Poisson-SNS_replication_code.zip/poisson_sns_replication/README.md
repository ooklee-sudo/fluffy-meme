# Replication code: Poisson-SNS (IEEE Access submission)

Study 4 of the manuscript: an implementation of the Study 1 scheduler comparison (IPP / HPP / fixed-period polling),
compared with public Bluesky and Stack Exchange activity. Python 3.10+; `pip install -r requirements.txt`.

## Steps
1. `./download_data.sh` fetches the public data into `./data` (about 1.8 GB Bluesky parquet, 0.4 GB Stack Exchange archives).
2. `cd data && python3 ../extract_bluesky.py && for s in money law workplace; do python3 ../extract_stackexchange.py $s; done && cd ..`
   builds `bsky_tid.parquet` (creation times decoded from AT Protocol TIDs) and `<site>_ref.npz`.
3. `python3 calibrate.py` (about 1 min) finds the surrogate-oracle intercept b0 so that a 24 h, 800-agent IPP run gives about 14,830 events (Section III-E). The value used in the paper is b0 = -2.87.
4. `python3 run_sim.py` runs 5 replications x 3 schedulers x 72 h (about 1 min) and writes `sim_study1.pkl`.
5. `python3 analyze.py` writes `study1_real_validation.json` (Tables VI and VII); `python3 make_figure.py` writes `fig4_public_data.png` (Fig. 4).
   Set `DATA_DIR` if the data are not in `./data`.

`sim_study1.pkl`, `study1_real_validation.json` and `fig4_public_data.png` are the outputs used in the paper, so steps 3 and 4 can be skipped.

## Files
- `poisson_sns.py`: event-driven simulator (platform, five personas, thinning-based IPP, HPP, polling, surrogate oracle).
- Assumptions not fixed by the manuscript: the functional form of the surrogate oracle (logistic in leisure time, relevant feed volume, relevance, notification and emotion).
- Stack Exchange hours are converted to US Eastern time; Bluesky hours are UTC.

## Data sources and licences
- Bluesky: `midwestern-simulation/12.1m_bluesky_posts` (Hugging Face); subject to Bluesky's terms of service.
- Stack Exchange data dump (Internet Archive), CC BY-SA.
