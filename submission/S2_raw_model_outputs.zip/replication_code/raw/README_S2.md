# Supplementary File S2: raw model outputs

Anonymized for double-anonymous review. Unzip this file inside the `replication_code` directory of Supplementary File S1 so that `raw/` sits next to `bank/`; the commands in that README then work unchanged.

| File | Content |
|---|---|
| `raw/main_run_raw.jsonl.gz` | All 176,400 calls of the main run (fourteen models, 12,600 calls each), one JSON object per line. |
| `raw/main.jsonl.meta.json` | Run metadata of the main run (hashes of the bank, prompts and runner). |
| `raw/extra_run_raw.jsonl.gz` | Complete call log of the analyses added after the main run (45,600 unique calls; retried credit errors remain as error rows, see the S1 README). |
| `raw/extra_pilot_raw.jsonl.gz` | The 1,450 pilot calls used to choose the models of the added analyses. |

Field names of the main run are listed in the S1 README (Data schema); the added log has the extra fields described there.
