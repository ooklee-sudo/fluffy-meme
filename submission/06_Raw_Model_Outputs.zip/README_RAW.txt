Raw model outputs (JSON lines, gzip). One line per API call.
Fields: study-specific. Common: pid (Twin-2K-500 participant id, "pid_<n>"), model, effort/temp/arch/template/arm (where applicable), content (model response text), cost (USD), qs/conds (questions shown and condition assignment).
Files: E1 (E1_full_runs.jsonl.gz), E2 (E2_reasoning_pilot.jsonl.gz), C1, H6c, C2 (C2_field_confirmatory), C2dev (development run on the exploratory package), S (stability study). tests.json is the selected Upworthy tests (headlines, impressions, clicks) for C2 and C2dev.
Persona text is not included (Twin-2K-500 CC BY 4.0 data are available from the original source).
