# Replication code: toy continual-learning unit test (CHBR-D-26-02301)

Re-implementation of the two-stream experiment (Stream A = insurance English, launch domain; Stream B = statutory English, later revision). The original script was lost, so this was rebuilt from the manuscript's Sec. 5.2 description. Numbers differ from the original Table 1.

## Run
    pip install -r requirements.txt
    python toy_cl.py --out toy_cl_results.json   # 3 seeds (13, 21, 37), ~9 min on 4 CPU cores
    python make_report.py                        # writes results_table.md and fig_forgetting.png

## Setup
- Word-level vocabulary (122 words) from template grammars; splits disjoint by exact sentence (seed 13: 2,800 train / 500 val / 700 test per stream).
- 2-layer pre-LN transformer, width 48, 4 heads, FFN 96, 50,976 parameters. Adam, lr 3e-3, batch 64; 10 epochs on A, then 8 on B.
- Cells: naive sequential; replay (A is 65% of each B batch); replay + proximal KL (b1=0.4); replay + dual KL (b1=0.4, b2=0.8); plus a launch-KL sweep (b2 in 0..3.2).
- Metric: next-token accuracy excluding pad, on held-out test sentences.

## Notes
- In a single A->B update the previous iterate and the launch checkpoint are the same network, so proximal KL and launch-checkpoint KL are the same penalty. Distinguishing them needs at least two updates (A->B->C), which is not implemented.
- Launch accuracy on A is about 0.65, near the entropy ceiling of the random slots.
- Three seeds: report ranges, not significance tests.

## Files
toy_cl.py, make_report.py, toy_cl_results.json (per-seed, per-epoch logs), results_table.md, fig_forgetting.png, run.log
