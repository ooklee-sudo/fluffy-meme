# Replication package: Mutation scores overstate the fault-finding reach of LLM-written unit tests

Code, prompts and derived results for the manuscript "Mutation Scores Overstate the Fault-Finding Reach of
LLM-Written Unit Tests: Evidence from Mutants and Real Faults".

## Requirements
Python 3.8-3.13, git, and network access to an OpenAI-compatible model gateway (OpenRouter; set `OPENROUTER_API_KEY`
in the environment, never in a file) for the generation steps. The scripts create per-project virtual environments.
No GPU. `pip install -r requirements.txt` is enough to rerun the analysis from the stored results.

## Layout and where each result comes from
| Part | Scripts | Results |
|---|---|---|
| Mutation study (RQ1): 11 modules of toolz, boltons, humanize, cachetools, more-itertools; 7 modules with >= 30 mutants analysed | `mutation/mutation_study.py` (operators in `mutation/mutation_pilot.py`, targets in `mutation/targets.json`) | `mutation/results/*.json`: per module, the human kill vector and, per model and attempt, the number of passing tests and the kill vector; `emse_mutation_modules.csv` |
| Harness check and fix | `mutation/check_ids.py` (finds truncated test ids), `mutation/recompute_kills.py` (recomputes kill vectors from the stored generated tests, no new model calls) | see Note below |
| Real faults (RQ2, RQ3): BugsInPy | `bugsinpy/bip_lib.py`, `bip_validate.py`, `bip_study.py`, `bip_calibrate.py` | `bugsinpy/valid_bugs.json` (229 bugs tried in 12 projects, 87 valid), `bugsinpy/results/*.json` (per bug and model: six attempts with test counts, failures on the faulty version and detection) |
| Tables 1-3 and Figure 1 | `emse_analysis.py` | `emse_results.json`, `emse_fig_reach.png` |

## Run order
Quick check from the stored results (seconds): `python3 emse_analysis.py`.

Full rerun:
1. `python3 bugsinpy/bip_validate.py --projects ...`
2. `python3 bugsinpy/bip_study.py run --models <comma list> --k 6 [--shard i/n]`
3. `python3 mutation/mutation_study.py run --models <comma list> --k 8 --max-mutants 150`
4. `python3 emse_analysis.py`

## Note (harness correction)
The first harness read the names of passing tests from pytest's console output. Names containing spaces were truncated,
and one project forces coloured output; in both cases the follow-up run failed to collect the test and every mutant was
counted as killed (or, with colour, every generated test was discarded). This affected humanize (both modules) and 5 of
24 attempts on boltons/strutils. The harness now reads exact test ids from JUnit XML; the affected kill vectors were
recomputed from the stored generated tests with `recompute_kills.py`. All other modules were unaffected (`check_ids.py`).

## Licence
MIT (see LICENSE). BugsInPy and the studied libraries are distributed under their own licences and are not included.
